# MCP 工具

`eltdx` 使用 MCP Python SDK 2 提供 stdio 服务。服务覆盖 7709 行情、K 线、分时、成交、竞价、短线指标，以及 7615 F10 和题材数据。

## 安装和启动

```bash
pip install "eltdx[mcp]"
eltdx-mcp
```

源码目录运行：

```bash
pip install -e ".[mcp]"
eltdx-mcp
```

MCP 客户端配置示例：

```json
{
  "mcpServers": {
    "eltdx": {
      "command": "eltdx-mcp"
    }
  }
}
```

Windows 上找不到脚本时，可以直接指定安装 `eltdx` 的 Python：

```json
{
  "mcpServers": {
    "eltdx": {
      "command": "C:\\path\\to\\python.exe",
      "args": ["-m", "eltdx.mcp"]
    }
  }
}
```

服务只使用 stdio，不开启 HTTP 端口。标准输出属于 MCP 协议通道，运行日志应写入标准错误。

## 工具列表 {#mcp-tools}

### 7709 行情

| 工具 | 作用 |
| --- | --- |
| `eltdx_quote` | 查询一个或多个证券的行情快照 |
| `eltdx_quote_depth` | 查询原生五档盘口，单次最多 100 只证券 |
| `eltdx_kline` | 查询一页 K 线，支持单只或多只证券、周期、复权和锚定日期 |
| `eltdx_capital_changes` | 查询标签 1..15 的股本变迁和权息资料，默认每批 75 只 |
| `eltdx_adjustment_factors` | 根据权息资料计算本地前、后复权系数，默认每批 75 只 |
| `eltdx_money_flow` | 查询最近日资金流向、主力/主买净额和两种口径的四档净额，默认每批 75 只 |
| `eltdx_daily_price_limits` | 按指定交易日的日线、权息和市场规则计算涨跌停价；`trade_date` 必填 |
| `eltdx_minute` | 查询当前或指定日期分时；`code` 可传单只或多只证券，列表时 `batch_size` 控制并发数 |
| `eltdx_trades` | 查询一页当前或历史成交明细；`code` 可传单只或多只证券，列表时 `batch_size` 控制并发数 |
| `eltdx_call_auction` | 查询当日或历史集合竞价过程快照；`trading_date` 可选 |
| `eltdx_opening_match_today` | 查询当日 09:25 正式撮合 |
| `eltdx_opening_match_history` | 查询历史 09:25 正式撮合 |
| `eltdx_auction_data` | 不传日期汇总当日竞价过程、09:25 正式撮合和前收盘参考价；传日期时用 `0x056a` 查询历史竞价过程，并用 `0x0fc6` 取得正式撮合和前收盘参考价 |

### 汇总与短线指标

| 工具 | 作用 |
| --- | --- |
| `eltdx_stock_profile` | 合并行情、代码表和财务基础信息 |
| `eltdx_shortline_indicators` | 返回交易日安全的 21 个短线指标字段 |

### 题材与 F10

| 工具 | 作用 |
| --- | --- |
| `eltdx_stock_topics` | 查询个股关联的全部题材 |
| `eltdx_topic_stocks` | 查询题材成分股及题材内对比数据 |
| `eltdx_limit_up_down_list` | 查询指定日期 / 日期范围的逐股涨停、炸板和跌停列表，可选市场概况 |
| `eltdx_limit_board_ladder` | `eltdx_limit_up_down_list` 的兼容名称 |
| `eltdx_company_profile` | 查询 F10 公司概况 |
| `eltdx_hot_topics` | 查询 F10 热点题材明细 |
| `eltdx_finance_report` | 查询 F10 财务报表 |
| `eltdx_company_news` | 查询 F10 公司资讯或研报 |
| `eltdx_market_news` | 查询资讯首页要闻流（滚动 / 今日焦点 / 要闻速递 / 正面 / 负面 / 精华 / 最新提示 / 机构调研） |
| `eltdx_channel_news` | 按频道号查询栏目资讯（84 个频道） |
| `eltdx_news_channels` | 列出全部资讯频道号与中文名 |

F10 工具保留服务端返回的原始字段名，同时在每个 `result_sets` 项中增加：

- `field_labels`：按 Entry、请求分区和响应模板解析的已确认中文字段名；财务报表覆盖 `zcfzb`、`lyb` 和 `xjllb`，并按 `nhytype` 区分通用企业、银行、券商和保险模板；
- `unmapped_fields`：当前分区尚未确认含义、或不能使用单一标签安全解释的原始字段名；
- `field_notes`：仅为当前结果中需要额外解释的字段返回口径说明，例如分组标题或动态扩展字段。

字段映射不会跨 Entry 或财务行业模板复用。例如通用企业资产负债表中的 `T039` 是“资产总计”，银行、券商和保险模板中的 `T039` 是“固定资产”，公司研报中的 `T039` 又是“研报标题”。财务工具读取元数据表的 `nhytype`（`0` 通用、`1` 银行、`2` 券商、`3` 保险）选择映射；缺少或遇到未知模板时不猜测。银行历史现金流量表的 `T088` 是随证券和报告期变化的动态扩展调节项，因此保留在 `unmapped_fields` 并通过 `field_notes` 解释，而不是强行指定统一中文名。原始 `columns`、`rows` 和 `row_cells` 不变，现有调用方可以继续按原字段读取。

### 文档

| 工具 | 作用 |
| --- | --- |
| `eltdx_docs_index` | 返回项目主要文档的 `eltdx://docs/*` resource URI |

服务还发布 `eltdx://docs/*` MCP resources，可直接读取 MCP、API、方法、字段、7709 命令、F10 和 Helper 文档。

## 调用示例

行情快照：

```json
{
  "codes": ["sz000001", "sh600000"],
  "timeout": 3
}
```

前复权日 K：

```json
{
  "code": "sz000001",
  "period": "day",
  "count": 120,
  "adjust": "qfq"
}
```

多只证券 K 线：

```json
{
  "code": ["sz000001", "sh600000"],
  "period": "day",
  "count": 120,
  "batch_size": 4
}
```

历史分时：

```json
{
  "code": "sz000001",
  "trading_date": "20260803"
}
```

多只证券分时或成交明细：

```json
{
  "code": ["sz000001", "sh600000"],
  "batch_size": 8
}
```

短线指标：

```json
{
  "codes": ["sz000001", "sh600000"],
  "refresh_stats": false
}
```

题材成分股：

```json
{
  "seed_code": "000034",
  "topic_name": "存储芯片",
  "sort_by": "zdf"
}
```

历史涨跌停列表：

```json
{
  "start_date": "20260807",
  "end_date": "20260810",
  "include_summary": true
}
```

该 Entry 没有服务端排序参数；排序下拉框属于页面本地逻辑，范围是每个日期的每个板位/状态分组内部。

## 参数和资源边界

| 参数 | 边界 |
| --- | --- |
| 普通行情和汇总工具 `codes` | 每次最多 200 个代码，建议使用 `sz000001`、`sh600000` 格式 |
| 股本变迁和复权系数 `codes` | 每次最多 200 个代码，默认每批 75 个；`batch_size` 可设为 `1..200` |
| 五档盘口 `codes` | `eltdx_quote_depth` 单次最多 100 个代码；底层使用原生 `0x0547` 刷新 / 推送接口 |
| `timeout` | 大于 0 且不超过 120 秒，默认 8 秒 |
| `host` | 可选的单个 7709 主站，例如 `HOST:PORT` |
| K 线 `count` | 每次最多 800 根 |
| K 线 `code` | 可传单个代码或最多 200 个代码；传列表时 `batch_size` 控制并发数 |
| 分时 / 成交 `code` | 可传单个代码或最多 200 个代码；传列表时 `batch_size` 控制并发数 |
| 成交 `count` | 每次最多 1800 条 |
| F10 `page_size` | 每次最多 100 条 |

服务按 `host + timeout` 复用 7709 客户端和内存缓存。同一配置只初始化一次，并固定建立 4 个连接槽位；同服务器的多个工具线程会由连接池分配到空闲 TCP 连接，最多 4 个行情请求同时在途，不会让多个线程直接共用同一个 socket。第 5 个及之后的并发请求按 FIFO 等待空闲槽位。最多保留 16 组行情客户端配置；达到上限时关闭并淘汰最久未使用的空闲客户端。服务退出会等待正在执行的行情调用完成，再统一关闭连接。

F10 工具走独立的 `7615/TQLEX` HTTP 调用，不占用 7709 行情客户端槽位。短线指标会使用 7709 行情和统计资源，并遵守交易日及 09:25 就绪检查。
